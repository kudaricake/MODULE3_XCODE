import UIKit

final class WelcomeViewController: UIViewController {
    @IBOutlet private weak var nameTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        nameTextField.delegate = self
        nameTextField.returnKeyType = .done
        nameTextField.layer.cornerRadius = 12
        nameTextField.layer.borderWidth = 1
        nameTextField.layer.borderColor = UIColor.systemGray4.cgColor
        nameTextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 14, height: 1))
        nameTextField.leftViewMode = .always
    }

    @IBAction private func exploreCampusTapped(_ sender: UIButton) {
        let name = nameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        performSegue(withIdentifier: "ShowAnnouncementsSegue", sender: name.isEmpty ? "Guest" : name)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let navigationController = segue.destination as? UINavigationController,
              let announcementsController = navigationController.topViewController as? AnnouncementsTableViewController else { return }
        announcementsController.visitorName = sender as? String ?? "Guest"
    }
}

extension WelcomeViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

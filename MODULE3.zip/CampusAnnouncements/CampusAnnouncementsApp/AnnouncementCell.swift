import UIKit

final class AnnouncementCell: UITableViewCell {
    @IBOutlet private weak var iconImageView: UIImageView!
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var dateLabel: UILabel!
    @IBOutlet private weak var categoryLabel: UILabel!
    @IBOutlet private weak var priorityLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        backgroundColor = .clear
        selectionStyle = .none
        contentView.layer.cornerRadius = 16
        contentView.layer.masksToBounds = true

        [iconImageView, titleLabel, dateLabel, categoryLabel, priorityLabel].forEach {
            $0?.translatesAutoresizingMaskIntoConstraints = false
        }
        NSLayoutConstraint.activate([
            iconImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 18),
            iconImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            iconImageView.widthAnchor.constraint(equalToConstant: 52),
            iconImageView.heightAnchor.constraint(equalToConstant: 52),
            titleLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 16),
            titleLabel.trailingAnchor.constraint(lessThanOrEqualTo: contentView.trailingAnchor, constant: -18),
            titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            dateLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            dateLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 5),
            categoryLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            categoryLabel.topAnchor.constraint(equalTo: dateLabel.bottomAnchor, constant: 5),
            priorityLabel.leadingAnchor.constraint(equalTo: categoryLabel.trailingAnchor, constant: 8),
            priorityLabel.centerYAnchor.constraint(equalTo: categoryLabel.centerYAnchor),
            priorityLabel.trailingAnchor.constraint(lessThanOrEqualTo: contentView.trailingAnchor, constant: -18)
        ])
    }

    func configure(with announcement: CampusAnnouncement) {
        iconImageView.image = UIImage(systemName: announcement.iconName)
        iconImageView.tintColor = announcement.priority == .urgent ? .systemRed : .systemBlue
        titleLabel.text = announcement.title
        dateLabel.text = announcement.date
        categoryLabel.text = announcement.category.uppercased()
        priorityLabel.text = announcement.priority == .urgent ? "URGENT" : ""
        priorityLabel.textColor = .systemRed
        contentView.backgroundColor = announcement.priority == .urgent ? UIColor.systemRed.withAlphaComponent(0.08) : .secondarySystemGroupedBackground
        contentView.layer.borderWidth = announcement.priority == .urgent ? 1 : 0
        contentView.layer.borderColor = UIColor.systemRed.withAlphaComponent(0.35).cgColor
    }
}

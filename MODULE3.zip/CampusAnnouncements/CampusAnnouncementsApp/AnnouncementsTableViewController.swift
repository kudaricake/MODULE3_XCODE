import UIKit

final class AnnouncementsTableViewController: UITableViewController {
    var visitorName = "Guest"
    private let announcements = CampusAnnouncement.samples

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Announcements"
        navigationItem.largeTitleDisplayMode = .always
        navigationController?.navigationBar.prefersLargeTitles = true
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor.systemGroupedBackground
        tableView.rowHeight = 112
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationItem.prompt = "Welcome, \(visitorName)"
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        announcements.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AnnouncementCell", for: indexPath)
        guard let announcementCell = cell as? AnnouncementCell else { return cell }
        announcementCell.configure(with: announcements[indexPath.row])
        return announcementCell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "ShowAnnouncementDetailSegue", sender: announcements[indexPath.row])
        tableView.deselectRow(at: indexPath, animated: true)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowAnnouncementDetailSegue",
              let detailController = segue.destination as? DetailViewController,
              let announcement = sender as? CampusAnnouncement else { return }
        detailController.announcement = announcement
    }
}

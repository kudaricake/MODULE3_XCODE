import Foundation

struct CampusAnnouncement {
    enum Priority: String {
        case normal = "Normal"
        case urgent = "Urgent"
    }

    let title: String
    let date: String
    let category: String
    let body: String
    let iconName: String
    let priority: Priority
    let postedBy: String

    static let samples: [CampusAnnouncement] = [
        CampusAnnouncement(
            title: "Campus Wellness Week",
            date: "October 14, 2026",
            category: "Student Life",
            body: "Join the Student Affairs Office for workshops, fitness sessions, and wellness activities across campus this week.",
            iconName: "heart.text.square.fill",
            priority: .normal,
            postedBy: "Student Affairs Office"
        ),
        CampusAnnouncement(
            title: "Library Hours Extended",
            date: "October 13, 2026",
            category: "Facilities",
            body: "The main library will remain open until 10:00 PM on weekdays during the midterm study period.",
            iconName: "books.vertical.fill",
            priority: .normal,
            postedBy: "University Library"
        ),
        CampusAnnouncement(
            title: "Emergency Drill Notice",
            date: "October 12, 2026",
            category: "Safety",
            body: "A campus-wide emergency preparedness drill will take place at 2:00 PM. Please follow instructions from safety marshals.",
            iconName: "exclamationmark.triangle.fill",
            priority: .urgent,
            postedBy: "Campus Safety Office"
        ),
        CampusAnnouncement(
            title: "Intramurals Registration",
            date: "October 10, 2026",
            category: "Sports",
            body: "Teams may register for this year's intramural basketball and volleyball leagues through the recreation portal.",
            iconName: "figure.basketball",
            priority: .normal,
            postedBy: "Office of Recreation"
        ),
        CampusAnnouncement(
            title: "Career Fair 2026",
            date: "October 8, 2026",
            category: "Career",
            body: "Meet employers, alumni, and internship partners at the annual campus career fair in the student center.",
            iconName: "briefcase.fill",
            priority: .normal,
            postedBy: "Career Development Center"
        ),
        CampusAnnouncement(
            title: "Water Service Interruption",
            date: "October 7, 2026",
            category: "Facilities",
            body: "Water service in the East Academic Building will be temporarily unavailable from 8:00 AM to 12:00 PM for maintenance.",
            iconName: "drop.triangle.fill",
            priority: .urgent,
            postedBy: "Facilities Management"
        )
    ]
}

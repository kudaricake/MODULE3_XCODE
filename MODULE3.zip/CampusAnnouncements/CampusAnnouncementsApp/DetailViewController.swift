import UIKit

final class DetailViewController: UIViewController {
    var announcement: CampusAnnouncement?

    @IBOutlet private weak var iconImageView: UIImageView!
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var dateLabel: UILabel!
    @IBOutlet private weak var categoryLabel: UILabel!
    @IBOutlet private weak var bodyLabel: UILabel!
    @IBOutlet private weak var postedByLabel: UILabel!
    @IBOutlet private weak var priorityLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Announcement"
        guard let announcement else { return }
        iconImageView.image = UIImage(systemName: announcement.iconName)
        iconImageView.tintColor = announcement.priority == .urgent ? .systemRed : .systemBlue
        titleLabel.text = announcement.title
        let metadata = "\(announcement.category.uppercased())  •  \(announcement.date)"
        dateLabel.text = metadata
        categoryLabel.text = metadata
        bodyLabel.text = announcement.body
        postedByLabel.text = "Posted by \(announcement.postedBy)"
        priorityLabel.text = announcement.priority == .urgent ? "URGENT" : ""
        priorityLabel.textColor = .systemRed
    }
}
